#for loop

#index variable
index = 0

for index in range(10,20):
    print(index)
