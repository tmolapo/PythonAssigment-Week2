#how to create a checkbox

#imports built-in tkinter module
from tkinter import *

win=Tk()

#shows programme title
win.title("Adding a Button")

#adding a button
btn1 = Button(win, text="Button 1", fg="black")
btn2 = Button(win, text="Button 2", fg="black")
btn3 = Button(win, text="Button 3", fg="black")
btn4 = Button(win, text="Button 4", fg="black")
btn1.pack()
btn2.pack()

btn3.pack(side =LEFT)
btn4.pack(side =RIGHT)

#closing tkinter loop
win.mainloop

