#Creating a checkbox GUI

#importing the built-in tkinter module in python
from tkinter import *

win=Tk()

#shows programme title
win.title("Checkbox")

#list checkbox items
cb = Checkbutton(win, text="Item One")
cb.pack()
cb = Checkbutton(win, text="Item Two")
cb.pack()
cb = Checkbutton(win, text="Item Three")
cb.pack()
cb = Checkbutton(win, text="Item Four")
cb.pack()

#closing tkinter loop
win.mainloop()

