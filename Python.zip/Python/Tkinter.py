# a digital GUI clock in python

#import tkinter and time package
from tkinter import *
import time

#the function that calls the time
def times():
    #this the format of how the
    current_time = time.strftime("%I: %M :%S :%p")
    clock_lbl=Label(root,font='berlin 80',bg="grey",fg='black',text=current_time)
    clock_lbl.after(200,times)
    clock_lbl.grid(row=0,column=1)

root=Tk()
#the application title
root.title("Digital GUI Clock")
times()
root.mainloop()
