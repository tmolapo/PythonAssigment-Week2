#employee bank statement

#ask for user details
name = input("Please enter your name: \n")
surname = input("Please enter your Surname: \n")

#ask for acc number
acc_num = int(input("Please enter your Account Number: \n"))

#ask for salary
salary = int(input("Please enter your Salary: (R) \n"))

#variables to hold tax
tax_salary = 0
new_salary = 0
pension_savings = 0

#tax calculation
def tax ():
    tax_salary = ((10/100) * (salary))
    return tax_salary

#pension calculation
def pension():
    pension_savings = ((15/100) * (salary))
    return pension_savings

#new salary calculation
def new_amount():
    new_salary = salary - tax() - pension()
    return new_salary

#display
print("******************Python Bank Statement*******************")
print("###########################################################")
print("Name: \t \t \t", name)
print("Surname: \t \t", surname)
print("Account Number: \t", acc_num)
print("Account Type: " + " \t \t Savings ")

print("-------------------------------------------------------------")

print("Your current salary: \t (R)", salary)
print("Your tax amount: \t (R)", tax())
print("Your pension amount: \t (R)", pension())

print("-------------------------------------------------------------")

print("Your current available amount: \t (R)", new_amount())

print("----------------------THANK YOU---------------------")


























