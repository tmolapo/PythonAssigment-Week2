#showing a calendar

#import calendar built-in python libraries
import calendar
import datetime

#set the calendar to begin on a Sunday
calendar.setfirstweekday(calendar.SUNDAY)

#shows the current year and month
print("----Python Calendar---- \n")
print(calendar.month(2020,8),"\n")

#checks current date
current = datetime.datetime.now()

#indicate the current year
day_index = calendar.weekday(2020,8,1)
month.index = calendar.month(2020,8,1)

#display full calendar

# %A is the full day
# %B is the full month name month
# %d is the day of the month
# &Y is the full year
print("Today is",current.strftime('%A %B %d %Y'))

