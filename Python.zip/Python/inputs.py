#creating checkboxes

#importing built-in tkinter modules
from tkinter import *

win=Tk()

#shows programme title
win.title("Adding inputbox")

#adding labels
label1 = Label(win, text="Enter your name:").place(x=4, y=10)
entry1=Entry(win).place(x=120,y=10)
label2 = Label(win, text="Enter your Surname:").place(x=4, y=40)
entry2=Entry(win).place(x=120,y=40)
label3 = Label(win, text="Enter your email:").place(x=4, y=70)
entry3=Entry(win).place(x=120,y=70)

#close
win.mainloop()

