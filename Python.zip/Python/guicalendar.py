#GUI Calendar

#import tkinter calendar package
from tkinter import*
import calendar

#function to display calendar

def show():
    a=spin1.get()
    b=spin2.get()
    a=int(a)
    b=int(b)
    cal=calendar.month(b,a)
    text1.delete(0.0,END)
    text1.insert(INSERT,cal)

root=Tk()
root.title("GUI Calendar")
root.geometry("260x240")

#months in a year
spin1=Spinbox(root,values=(1,2,3,4,5,6,7,8,9,10,11,12),width=5)
spin1.place(x=40,y=0)

#calendar display date from 1878 to 2100
spin2=Spinbox(root,from_=1878, to=2100,width=6)
spin2.place(x=100,y=0)

#placing the button
button1=Button(root,text="Show calendar",command=show, bg='dark grey')
button1.place(x=40,y=40,width=110)

#displaying calendar text area
text1=Text(root,width=22,height=8)
text1.place(x=20,y=90)

root.mainloop()
