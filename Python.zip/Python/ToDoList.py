#TODO List GUI application

#tkinter package
from tkinter import*

win=Tk()
win.title("GUI """"'TO-DO'"""" Application")


the_list= Listbox(win,font="Arial 14 bold", width=20, height=10)
task = StringVar()
entry=Entry(win,font="Arial 12",width=22,textvariable=task)

#adding new task
add_button = Button(win,text="Add Task",width=10,
            command=lambda the_list=the_list,task=task:
            the_list.insert(END, task.get(), task.set("")))

#delete a task
delete_button = Button(win,text="Delete Task", width=10,
                command=lambda the_list=the_list:
                the_list.delete(ANCHOR))

#placing all elements
the_list.grid(row=0, column=0,columnspan=2,padx=6,pady=5)
entry.grid(row=1, column=0,columnspan=2,padx=5,pady=5)
add_button.grid(row=2,column=0)
delete_button.grid(row=2,column=1)

win.mainloop()
