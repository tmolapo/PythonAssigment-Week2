#Creating a Simple menu

#imports the built-in tkinter module
from tkinter import *

win=Tk()

#shows the programme title
win.title("Simple Menu")

#list items in the menu
m = Menu(win)
m.add_cascade(label="File", command=win.quit)
m.add_cascade(label="Edit", command=win.quit)
m.add_cascade(label="Help", command=win.quit)
m.add_cascade(label="Tools", command=win.quit)

win.config(menu=m)

#closing the tkinter loop
win.mainloop()
